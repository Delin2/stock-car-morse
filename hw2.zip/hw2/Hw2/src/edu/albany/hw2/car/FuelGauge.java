package edu.albany.hw2.car;

public class FuelGauge {
	public final int MAX_GALLONS = 15;
	private int gallons;
	
	public FuelGauge() {
		gallons = 0;
	}
		
	public FuelGauge(int g){
		if(gallons <= MAX_GALLONS) 
			this.gallons=g;
		else
			gallons = MAX_GALLONS;
	}
	
	//Getter for gallons
	public int getGallons() {
		return gallons;
	}
	
	//To increment
	public void incrementGallons() {
		if(gallons < MAX_GALLONS)
			gallons++;
		else
			System.out.println("Fuel Overflowing");
	}
	
	//To decrement
	public void decrementGallons() {
		if(gallons > 0)
			gallons--;
		else
			System.out.println("Out of Fuel");
	}
}
