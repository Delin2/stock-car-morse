package edu.albany.hw2.car;

public class Odometer{
	public final int MAX_MILEAGE=999999;
	public final int MPG = 22;
	private int initialMileage;
	private int mileage;
	private FuelGauge fuelGauge;
	
	
	//Constructor for Odometer
	public Odometer(int m, FuelGauge fg) {
		this.initialMileage = mileage;
		this.mileage=m;
		this.fuelGauge=fg;
	}
	
	//Getter for mileage
	public int getMileage(){
		return mileage;
	}
	
	/*To increment mileage, when mileage goes over Max_Mileage(999999) it resets to 0.
	 * When mileage increments 22 times(MPG) then it decrement gallons by 1
	 */
	public void incrementMileage(){
		if(mileage < MAX_MILEAGE)
			mileage++;
		else {
			mileage = 0;
		}
		
		int driven = initialMileage - mileage;
		if(driven % MPG == 0) {
			fuelGauge.decrementGallons();
		}
	}
}
