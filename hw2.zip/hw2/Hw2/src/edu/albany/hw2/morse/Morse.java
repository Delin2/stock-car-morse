package edu.albany.hw2.morse;

/*Strategy to store the morse code encoding table
 * By using if-else statements to control the output.So that the Morse code is created once
 * the condition is satisfied for the appropriate statements to be shown
 */

public class Morse {
	//Constructor
	public Morse(){
		
	}
	
	//To convert the string to Morse code
	public String convert(String s){
		StringBuffer m = new StringBuffer();
		for(int i = 0; i < s.length(); i++){
			m.append(toMorse(String.valueOf(s.charAt(i))));
			m.append(" ");//space between letters
		}
		return m.toString();
	}
	
	//Cases to convert to Morse code
	public String toMorse (String orig)
    {
        String morse = "";

        if(orig.equalsIgnoreCase("a"))
            morse = ".-";
        else if(orig.equalsIgnoreCase("b"))
            morse = "-...";
        else if(orig.equalsIgnoreCase("c"))
            morse = "-.-.";
        else if(orig.equalsIgnoreCase("d"))
            morse = "-..";
        else if(orig.equalsIgnoreCase("e"))
            morse = ".";
        else if(orig.equalsIgnoreCase("f"))
            morse = "..-.";
        else if(orig.equalsIgnoreCase("g"))
            morse = "--.";
        else if(orig.equalsIgnoreCase("h"))
            morse = "....";
        else if(orig.equalsIgnoreCase("i"))
            morse = "..";
        else if(orig.equalsIgnoreCase("j"))
            morse = ".---";
        else if(orig.equalsIgnoreCase("k"))
            morse = "-.-";
        else if(orig.equalsIgnoreCase("l"))
            morse = ".-..";
        else if(orig.equalsIgnoreCase("m"))
            morse = "--";
        else if(orig.equalsIgnoreCase("n"))
            morse = "-.";
        else if(orig.equalsIgnoreCase("o"))
            morse = "---";
        else if(orig.equalsIgnoreCase("p"))
            morse = ".--.";
        else if(orig.equalsIgnoreCase("q"))
            morse = "--.-";
        else if(orig.equalsIgnoreCase("r"))
            morse = ".-.";
        else if(orig.equalsIgnoreCase("s"))
            morse = "...";
        else if(orig.equalsIgnoreCase("t"))
            morse = "-";
        else if(orig.equalsIgnoreCase("u"))
            morse = "..-";
        else if(orig.equalsIgnoreCase("v"))
            morse = "...-";
        else if(orig.equalsIgnoreCase("w"))
            morse = ".--";
        else if(orig.equalsIgnoreCase("x"))
            morse = "-..-";
        else if(orig.equalsIgnoreCase("y"))
            morse = "-.--";
        else if(orig.equalsIgnoreCase("z"))
            morse = "--..";
        else if(orig.equalsIgnoreCase("0"))
            morse = "-----";
        else if(orig.equalsIgnoreCase("1"))
            morse = ".----";
        else if(orig.equalsIgnoreCase("2"))
            morse = "..---";
        else if(orig.equalsIgnoreCase("3"))
            morse = "...--";
        else if(orig.equalsIgnoreCase("4"))
            morse = "....-";
        else if(orig.equalsIgnoreCase("5"))
            morse = ".....";
        else if(orig.equalsIgnoreCase("6"))
            morse = "-....";
        else if(orig.equalsIgnoreCase("7"))
            morse = "--...";
        else if(orig.equalsIgnoreCase("8"))
            morse = "---..";
        else if(orig.equalsIgnoreCase("9"))
            morse = "----.";
        else if(orig.equalsIgnoreCase("."))
            morse = ".-.-";
        else if(orig.equalsIgnoreCase(","))
            morse = "--..--";
        else if(orig.equalsIgnoreCase("?"))
            morse = "..--..";
        else if(orig.equalsIgnoreCase(" "))
        	morse = " ";

        return morse;
    }
}