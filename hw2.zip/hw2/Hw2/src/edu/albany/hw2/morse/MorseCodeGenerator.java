package edu.albany.hw2.morse;

import java.util.Scanner;

public class MorseCodeGenerator {
	//User can input a string via command line
	public static void main(String[] args) {
		if (args.length > 1) {
			System.out.println("Please enter the correct " 
					+ "amount of command line arguments");
		}else if (args.length == 1) {//command line argument
			Morse m = new Morse();
			System.out.println("Your String: " + args[0]);
			System.out.println("The Morse code is: " + m.convert(args[0]));
		}else {//asks the user for input
			Scanner s = new Scanner(System.in);
			System.out.println("What do you want to convert to Morse code:");
			String input = s.nextLine();
			Morse m = new Morse();
			System.out.println("Your String: " + input);
			System.out.println("The Morse code is: " + m.convert(input));
			s.close();
		}
	}

}
