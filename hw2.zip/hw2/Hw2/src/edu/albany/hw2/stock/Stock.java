package edu.albany.hw2.stock;

public class Stock {
	private String name;
	Symbol sym;
	private double previousClosingPrice;
	private double currentPrice;
	
	//constructor
	public Stock(String na, Symbol s) {
		this.name=na;
		this.sym=s;
	}
	
	//Gets name
	public String getName() {
		return name;
	}
	
	//Sets the name
	public void setName(String na) {
		this.name = na;
	}
	
	//Gets current price
	public double getCurr() {
		return currentPrice;
	}
	
	/*Sets the current price as the previous price 
	**so that the new previous price is the old current price
	**then sets the new current price
	*/
	public void setCurr(double curr) {
		this.previousClosingPrice = this.currentPrice;
		this.currentPrice = curr;
	}
	
	//Gets previous price
	public double getPrev() {
		return previousClosingPrice;
	}
	
	//Sets the previous
	public void setPrev(double prev) {
		this.previousClosingPrice = prev;
	}
	
	//Gets the percentage change
	public double getChangePercentage() {
		return ((currentPrice - previousClosingPrice)/previousClosingPrice)*100;
	}
}
