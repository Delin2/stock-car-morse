package edu.albany.hw2.stock;

public class StockTest {

	public static void main(String[] args) {
		Stock stock1 = new Stock("Microsoft", Symbol.Microsoft);
		Stock stock2 = new Stock("Google", Symbol.Google);
		stock1.setCurr(58.9);
		stock1.setCurr(59);
		System.out.println("Stock Name: " + stock1.getName());
		System.out.println("Symbol: " + Symbol.Microsoft.getSym());
        System.out.println("Previous Price: " + stock1.getPrev());
        System.out.println("Current Price: " + stock1.getCurr());
        System.out.println("Percentage changed: " + stock1.getChangePercentage());
		stock2.setCurr(58.9);
		stock2.setCurr(59);
		System.out.println("Stock Name: " + stock2.getName());
		System.out.println("Symbol: " + Symbol.Google.getSym());
        System.out.println("Previous Price: " + stock2.getPrev());
        System.out.println("Current Price: " + stock2.getCurr());
        System.out.println("Percentage changed: " + stock2.getChangePercentage());
	}

}
