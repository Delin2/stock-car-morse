package edu.albany.hw2.stock;

public enum Symbol {
	Microsoft("MSFT"), 
	Apple("APPL"),
	Google("GOOG"),
	Amazon("AMZN"),
	ATT("T");
	
	private final String sym;
	
	private Symbol(String s) {
		this.sym = s;
	}
	
	public String getSym() {
		return sym;
	}
}